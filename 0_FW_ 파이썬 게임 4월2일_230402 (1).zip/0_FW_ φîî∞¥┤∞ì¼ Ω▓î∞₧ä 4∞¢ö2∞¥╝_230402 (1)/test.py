import pygame
import random

# 초기화
pygame.init()

# 게임 창 설정
screen_width = 480
screen_height = 900
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("슈팅 게임")

# 시계 설정
clock = pygame.time.Clock()
clock.tick(60) 
# 배경 이미지 설정
background = pygame.image.load("배경화면.png").convert()

# 비행기 이미지 설정
aircraft = pygame.image.load("비행선.png").convert_alpha()
aircraft_width, aircraft_height = aircraft.get_size()
aircraft_x_pos = (screen_width / 2) - (aircraft_width / 2)
aircraft_y_pos = screen_height - aircraft_height

# 총알 이미지 설정
bullet = pygame.image.load("총알.png").convert_alpha()
bullet_width, bullet_height = bullet.get_size()
bullet_speed = 10
bullet_state = "ready"

# 적 이미지 설정
enemy_images = [
    pygame.image.load("잡몹1.png").convert_alpha(),
    pygame.image.load("잡몹2.png").convert_alpha(),
    pygame.image.load("잡몹3.png").convert_alpha(),
]
enemy_speeds = [5, 7, 9]

# 적 생성
enemies = []
enemy_spawn_time = 1000
last_spawn_time = pygame.time.get_ticks()
enemy_loss_count = 0
font = pygame.font.Font(None, 30)

# 게임 루프
running = True
while running:
    # 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # 방향키 입력 받기
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                aircraft_x_pos -= 10
            elif event.key == pygame.K_RIGHT:
                aircraft_x_pos += 10
            elif event.key == pygame.K_UP:
                aircraft_y_pos -= 10
            elif event.key == pygame.K_DOWN:
                aircraft_y_pos += 10
            elif event.key == pygame.K_SPACE:
                if bullet_state == "ready":
                    bullet_x_pos = aircraft_x_pos + (aircraft_width / 2) - (bullet_width / 2)
                    bullet_y_pos = aircraft_y_pos - bullet_height
                    bullet_state = "fire"

    # 비행기 이동 범위 처리
    if aircraft_x_pos < 0:
        aircraft_x_pos = 0
    elif aircraft_x_pos > screen_width - aircraft_width:
        aircraft_x_pos = screen_width - aircraft_width
    if aircraft_y_pos < 0:
        aircraft_y_pos = 0
    elif aircraft_y_pos > screen_height - aircraft_height:
        aircraft_y_pos = screen_height - aircraft_height

    # 배경 그리기
    screen.blit(background, (0, 0))

    # 비행기 그리기
    screen.blit(aircraft, (aircraft_x_pos, aircraft_y_pos))

    # 총알 처리
    if bullet_state == "fire":
        bullet_y_pos -= bullet_speed
        if bullet_y_pos < 0:
            bullet_state = "ready"
        else:
            screen.blit(bullet, (bullet_x_pos, bullet_y_pos))

    # 적 생성 처리
    now = pygame
