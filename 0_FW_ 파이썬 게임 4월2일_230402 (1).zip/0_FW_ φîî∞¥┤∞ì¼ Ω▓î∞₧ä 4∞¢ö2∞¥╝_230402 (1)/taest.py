import pygame

pygame.init()

# 게임 화면 설정
screen_width = 480
screen_height = 640
screen = pygame.display.set_mode((screen_width, screen_height))

pygame.display.set_caption("My Game")

# 비행선 이미지 불러오기
spaceship = pygame.image.load("비행선.png")
spaceship_size = spaceship.get_rect().size
spaceship_width = spaceship_size[0]
spaceship_height = spaceship_size[1]
spaceship_x_pos = (screen_width - spaceship_width) / 2
spaceship_y_pos = screen_height - spaceship_height

# 비행선 이동 속도
spaceship_speed = 5.0

# 이동 방향 변수
to_x = 0
to_y = 0

# 이벤트 루프
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # 키를 눌렀을 때
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                to_x -= spaceship_speed
            elif event.key == pygame.K_RIGHT:
                to_x += spaceship_speed
            elif event.key == pygame.K_UP:
                to_y -= spaceship_speed
            elif event.key == pygame.K_DOWN:
                to_y += spaceship_speed

        # 키에서 손을 떼었을 때
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                to_x = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                to_y = 0
            elif event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                to_x = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                to_y = 0

    # 비행선 이동
    spaceship_x_pos += to_x
    spaceship_y_pos += to_y

    # 화면 경계 설정
    if spaceship_x_pos < 0:
        spaceship_x_pos = 0
    elif spaceship_x_pos > screen_width - spaceship_width:
        spaceship_x_pos = screen_width - spaceship_width

    if spaceship_y_pos < 0:
        spaceship_y_pos = 0
    elif spaceship_y_pos > screen_height - spaceship_height:
        spaceship_y_pos = screen_height - spaceship_height

    # 화면에 비행선 그리기
    screen.blit(spaceship, (spaceship_x_pos, spaceship_y_pos))

    # 화면 업데이트
    pygame.display.update()

# 게임 종료
pygame.quit()
